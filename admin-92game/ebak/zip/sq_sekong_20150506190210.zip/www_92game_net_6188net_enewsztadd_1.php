<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `www_92game_net_6188net_enewsztadd`;");
E_C("CREATE TABLE `www_92game_net_6188net_enewsztadd` (
  `ztid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `classtext` mediumtext NOT NULL,
  `guanyu` text NOT NULL,
  PRIMARY KEY (`ztid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `www_92game_net_6188net_enewsztadd` values('1','','古典美女，顾名思义：穿着各类或古代或近代的服装的各类美女；或妖媚或清纯；古典美女给人予一种高贵典雅的视觉感受。');");
E_D("replace into `www_92game_net_6188net_enewsztadd` values('2','','王馨瑶yanni，1992年9月6日出生，演员，2012世界旅游小姐大赛广东赛区季军，推女郎模特。');");
E_D("replace into `www_92game_net_6188net_enewsztadd` values('3','','本专题以美腿写真为主，搜集来自套图屋主打官方发布的腿图，其次还有台湾当地某些新闻发布会拍摄的腿图，即Beautyleg新闻图片。另外官方也会定期放出写真视频。Beautyleg系列以美腿著称，当然首先看重的是模特腿形!');");
E_D("replace into `www_92game_net_6188net_enewsztadd` values('4','','性感撩人的浴室美女，湿身诱惑无极限，浴室里的美女火辣的身材每一样都带给你不一样的视觉感受！');");
E_D("replace into `www_92game_net_6188net_enewsztadd` values('5','','本专题收录了关于陈紫函，个人的、影视的写真集合；从各个方面记录其从出道至今的各类高清写真集合。');");
E_D("replace into `www_92game_net_6188net_enewsztadd` values('6','','林志玲拥有清秀面庞配着志玲招牌甜甜微笑，气质优雅，透着完美女神的优雅气质，集美丽与智慧于一身。下面是小编精心收集的关于林志玲姐姐的性感，火辣美照，一起来看看吧!');");
E_D("replace into `www_92game_net_6188net_enewsztadd` values('7','','足球宝贝是一些美丽漂亮的女孩，多为抱着足球，穿着各队球衣，秀出各种可人姿态，为球队拉人气。各种性感的，火辣的，妩媚的足球宝贝专题。');");
E_D("replace into `www_92game_net_6188net_enewsztadd` values('8','','cosplay美女专题整理了各类游戏角色、动漫角色的高清美女写真，各类美女通过动漫、游戏、影视服装,制服、SD洋装、LOLITA洋装、晚礼服装、欧洲宫廷服装、日本校服、水手服、古装服饰，展现了cosplay的烂漫清新的唯美现实');");
E_D("replace into `www_92game_net_6188net_enewsztadd` values('9','','比基尼美女专题整理了各类最新的高清比基尼美女图片，比基尼泳装美女可以说是服装史上最具有视觉冲击力的美女服装。背后系带的胸衣和三角裤的装束不亚于原子弹爆炸。');");
E_D("replace into `www_92game_net_6188net_enewsztadd` values('10','','张婉悠美女专题整理了，关于张婉悠的一些个人私密的写真集和“门”事件的艳照，以及各类时尚杂志邀请张婉悠拍摄的杂志封面');");

@include("../../inc/footer.php");
?>