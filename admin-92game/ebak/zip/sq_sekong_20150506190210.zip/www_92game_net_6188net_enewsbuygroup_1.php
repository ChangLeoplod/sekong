<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `www_92game_net_6188net_enewsbuygroup`;");
E_C("CREATE TABLE `www_92game_net_6188net_enewsbuygroup` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `gname` varchar(255) NOT NULL DEFAULT '',
  `gmoney` int(10) unsigned NOT NULL DEFAULT '0',
  `gfen` int(10) unsigned NOT NULL DEFAULT '0',
  `gdate` int(10) unsigned NOT NULL DEFAULT '0',
  `ggroupid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gzgroupid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `buygroupid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `gsay` text NOT NULL,
  `myorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8");
E_D("replace into `www_92game_net_6188net_enewsbuygroup` values('1','vip月卡','10','0','30','2','1','1','vip月卡','0');");
E_D("replace into `www_92game_net_6188net_enewsbuygroup` values('2','vip季卡','25','0','90','2','1','1','vip季卡','0');");
E_D("replace into `www_92game_net_6188net_enewsbuygroup` values('3','vip半年卡','50','0','180','2','1','1','vip半年卡','0');");

@include("../../inc/footer.php");
?>